/* This code was written by Herve Jegou. Contact: herve.jegou@inria.fr  */
/* Last change: June 1st, 2010                                          */
/* This software is governed by the CeCILL license under French law and */
/* abiding by the rules of distribution of free software.               */
/* See http://www.cecill.info/licences.en.html                          */

#include <stdio.h>
#include "mex.h"
#include <math.h>

#define uint8 unsigned char

void mexFunction (int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray*prhs[])

{
  if (nrhs != 3) 
    mexErrMsgTxt ("Invalid number of input arguments");
  
  if (nlhs > 1)
    mexErrMsgTxt ("This function output exactly 1 argument");


  if (mxGetClassID(prhs[0]) != mxUINT8_CLASS)
    mexErrMsgTxt ("first argument should uint8 type"); 
  
  if (mxGetClassID(prhs[1]) != mxSINGLE_CLASS)
      mexErrMsgTxt ("second argument should single precision array");
  
  if (mxGetClassID(prhs[2]) != mxSINGLE_CLASS)
      mexErrMsgTxt ("third argument should single precision array");

  uint8 *idx = (uint8*)mxGetPr(prhs[0]);
  float *coef = (float*) mxGetPr (prhs[1]);
  float *T = (float*) mxGetPr(prhs[2]);
  const mwSize *dims = mxGetDimensions(prhs[0]);
  
  int L = (int)dims[0]; /* sparse level */
  int n = (int)dims[1]; /* size of vector*/
  int m = (int)dims[2]; /*number of segment*/
  int numcenter = (int)mxGetM(prhs[2]);
  
  
  plhs[0] = mxCreateNumericMatrix (n, 1, mxSINGLE_CLASS, mxREAL);
  float *dis = (float*) mxGetPr (plhs[0]);
  
  int i,j,k;
  float *ptable;
  for (i = 0 ; i < n ; i++)
       dis[i] = 0;
  
  for(i=0; i < m; i++){
      ptable = T+i*numcenter;
    for(j=0; j < n; j++)          
        for(k=0; k < L;k++){
          dis[j] -= *coef*ptable[*idx];
           
          ++coef;
          ++idx;

        }
  }
 
    
}
