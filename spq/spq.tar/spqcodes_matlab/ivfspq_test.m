function ivfspq_test()
dataset = 'random';
pq_test_load_vectors;

k = 100;              % number of elements to be returned
nsq = 8;              % number of subquantizers to be used (m in the paper)
coarsek = 256;        % number of centroids for the coarse quantizer
w = 8;                % number of cell visited per query
ks = 8;
ds = size(vtrain,1)/nsq;
L = 2;


%% Learn the SPQ codebook and inverted file structure
t0 = cputime;
ivfspq.coarsek = coarsek;

% first learn the coarse quantizer
niter = 50;
ivfspq.coa_centroids = yael_kmeans (vtrain, coarsek, 'niter', niter, 'verbose', 0);
[idx, dis] = yael_nn (ivfspq.coa_centroids, vtrain);

opt.K = 2^ks;
opt.mode = 3;
opt.lambda = 2;
opt.iter = 15;
opt.verbose = 0;
dicts = cell(nsq,1);
for i = 1:nsq
    xsub = vtrain((1:ds) + (i-1)*ds,:);

    dict = mexTrainDL(xsub,opt);
    dicts{i} = dict;
end
tpqlearn = cputime - t0;



%% encode the database vectors: 
% ivf is a structure containing three sets of k cells
% Each cell contains a set of idx/codes/coef associated with a given coarse centroid
t0 = cputime;
% find the indexes for the coarse quantizer
[coaidx, dumm] = yael_nn (ivfspq.coa_centroids, vbase);
bdis = sum(vbase.*vbase)';
n = size(vbase,2);
optomp.L = L; 
optomp.eps = 0.001;
distortion = zeros(1,n,'single');
idxencode = ones(L,n,nsq,'uint8');
coefencode = zeros(L,n,nsq,'single');
for i = 1:nsq
     xsub = vbase((1:ds) + (i-1)*ds,:);
     coef = mexOMP(xsub,dicts{i},optomp);

     [row,col,v] = find(coef);
     [idxencode(:,:,i), coefencode(:,:,i)] = formatidx(uint8(row-1),int32(col),single(v),L,n);
     
     
     dx = xsub - dicts{i}*full(coef);
     distortion = distortion + sum(dx.*dx);
end
ivf.cellpop = hist (double(coaidx), 1:ivfspq.coarsek);
[coaidx, ids] = sort (coaidx);
idxencode = idxencode(:,ids,:);
coefencode = coefencode(:,ids,:);

ivf.ids = cell (ivfspq.coarsek, 1);   % vector identifiers
ivf.codes = cell (ivfspq.coarsek, 1);
pos = 1;
for i=1:ivfspq.coarsek
   nextpos = pos+ivf.cellpop(i);
   ivf.ids{i} = ids (pos:nextpos-1);
   ivf.idxcode{i} = idxencode(:, pos:nextpos-1,:);
   ivf.coefcode{i} = coefencode(:, pos:nextpos-1,:);
   pos = nextpos;
end
tpqencode = cputime - t0;



%% ---[ perform the search and compare with the ground-truth ]---
t0 = cputime;
[coaidx, coadis] = yael_nn (ivfspq.coa_centroids, vquery, w);

distab  = zeros (opt.K, nsq, 'single');
dis_pqc = zeros (nquery, k, 'single');
ids_pqc = zeros (nquery, k, 'single');
for query = 1:nquery

  % indexs of selected list to approximate
  qcoaidx = coaidx (:, query);

  for q = 1:nsq
      vsub = vquery ((q-1)*ds+1:q*ds, query);
      distab(:,q)= dicts{q}'*vsub;
  end
    
  
  % seperatively approximating each list/cell.
  qdis = zeros(sum(ivf.cellpop(qcoaidx)),1,'single');
  pos = 1;
  for j = 1:w
    nextpos = pos+ivf.cellpop(qcoaidx(j));
    qdis(pos:nextpos-1) = sumidxtab3(ivf.idxcode{qcoaidx(j)},ivf.coefcode{qcoaidx(j)},distab);
    pos = nextpos;
  end
  qidx = cat(2,ivf.ids{qcoaidx});
  
  % Comment this if database vectors are L2-normalized
  qdis = 2*qdis + bdis(qidx');
  
  
  ktmp = min (k, length (qdis));
   [dis1, ids1] = yael_kmin (qdis, ktmp);
   
  dis_pqc(query, 1:ktmp) = dis1;
  ids_pqc(query, 1:ktmp) = qidx(ids1);
end
tpqsearch = cputime - t0;


%% print out inform
fprintf('====================\n');
fprintf ('IVF_SPQ_ADC learn  = %.3f s\n', tpqlearn);
fprintf ('IVF_SPQ_ADC encode = %.3f s\n', tpqencode);
fprintf ('IVF_SPQ_ADC search = %.3f s  for %d query vectors in a database of %d vectors\n\n', ...
	 tpqsearch, nquery, nbase);


%% ---[ Compute search statistics ]---
pq_test_compute_stats