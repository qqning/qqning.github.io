addpath ('/media/winf/research/code/yael_v438/matlab')
addpath('/media/winf/research/code/spams-matlab/build/');
compile;

pq_test;
spq_test;

% ivfpq_test;
% ivfspq_test;