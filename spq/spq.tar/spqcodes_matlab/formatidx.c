/* This code was written by Herve Jegou. Contact: herve.jegou@inria.fr  */
/* Last change: June 1st, 2010                                          */
/* This software is governed by the CeCILL license under French law and */
/* abiding by the rules of distribution of free software.               */
/* See http://www.cecill.info/licences.en.html                          */

#include <stdio.h>
#include <memory.h>
#include "mex.h"

#define uint8 unsigned char

void mexFunction (int nlhs, mxArray *plhs[],
                  int nrhs, const mxArray*prhs[])

{
  if (nrhs != 5) 
    mexErrMsgTxt ("Invalid number of input arguments");
  
  if (nlhs != 2)
    mexErrMsgTxt ("This function output exactly 1 argument");


  if (mxGetClassID(prhs[0]) != mxUINT8_CLASS)
      mexErrMsgTxt ("the argument should be uint8 array");
  if (mxGetClassID(prhs[1]) != mxINT32_CLASS)
      mexErrMsgTxt ("the argument should be uint8 array");
  if (mxGetClassID(prhs[2]) != mxSINGLE_CLASS)
      mexErrMsgTxt ("the argument should be uint8 array");


  uint8 * rowp = (uint8*) mxGetPr(prhs[0]); 
  int * colp = (int*) mxGetPr(prhs[1]); 
  float * coefp = (float*) mxGetPr(prhs[2]); 
  int L = (int) mxGetScalar(prhs[3]);
  int n = (int) mxGetScalar(prhs[4]);
  int num = (int)mxGetNumberOfElements(prhs[0]);

  plhs[0] = mxCreateNumericMatrix (L, n, mxUINT8_CLASS, mxREAL);
  uint8 *oidx = (uint8*) mxGetPr (plhs[0]);
  plhs[1] = mxCreateNumericMatrix (L, n, mxSINGLE_CLASS, mxREAL);
  float *ocoef = (float*) mxGetPr (plhs[1]);
  

  int i,z=0,i2,i1 = 0;
  memset(oidx,0,L*n*sizeof(uint8));
  memset(ocoef,0,L*n*sizeof(float));
  

  for(i=0; i< num;i++){
      i2 = *colp;
      
      if(i1 == i2)
          z++;
      else{
          z = L*(i2-1);
      }
      oidx[z] = *rowp;
      ocoef[z] = *coefp;
      
      colp++;
      rowp++;
      coefp++;
      i1 = i2;
  }
  
}
