function spq_test()

% load the vectors from test/training/query sets, and the groundtruth
% if dataset='random', a random dataset is generated on the fly
%           ='siftsmall', the siftsmall is used (from basedir directory)
%           ='sift', the sift dataset is used (frome basedir directory)
%           ='gist', the sift dataset is used (frome basedir directory)
dataset = 'random';
pq_test_load_vectors;
% 
% %---[ Search parameters ]---
% 
k = 100;             % number of elements to be returned
nsq = 8;             % number of subquantizers to be used (m in the paper)
ks = 8;

ds = size(vtrain,1)/nsq;

% Learn the SPQ code structure
t0 = cputime;

clear opt;
opt.K = 2^ks;
opt.lambda = 0.15;
opt.iter = 15;
opt.verbose = 0;

opt.mode = 3;
opt.lambda = 2;


dicts = cell(nsq,1);
for i = 1:nsq
    xsub = vtrain((1:ds) + (i-1)*ds,:);    
    dict = mexTrainDL(xsub,opt);
    dicts{i} = dict;
end
tpqlearn = cputime - t0;
fprintf('codebook done!\n');

% encode the database vectors
t0 = cputime;

n = size(vbase,2);

% sparse level, L=2 is enough to have good result
optomp.L = 2; 
optomp.eps = 0.001;
distortion = zeros(1,n,'single');
idxencode = ones(optomp.L,n,nsq,'uint8');
coefencode = zeros(optomp.L,n,nsq,'single');
for i = 1:nsq
     xsub = vbase((1:ds) + (i-1)*ds,:);
     coef = mexOMP(xsub,dicts{i},optomp);

     
     % if using mexOMP, the notzero number of coefficient is not fixed(not large than optomp.L),
     % we need row and column number to index the code.
     [row,col,v] = find(coef);
     [idxencode(:,:,i), coefencode(:,:,i)] = formatidx(uint8(row-1),int32(col),single(v),optomp.L,n);
     
     
     dx = xsub - dicts{i}*full(coef);
     distortion = distortion + sum(dx.*dx);
end
fprintf('encoding done\n');
tpqencode = cputime - t0;


%---[ perform the search and compare with the ground-truth ]---
t0 = cputime;

distab  = zeros (opt.K, nsq, 'single');
dis_pqc = zeros (nquery, k, 'single');
ids_pqc = zeros (nquery, k, 'single');
bdot = sum(vbase.*vbase)';
for q = 1:nquery
    
    for i = 1:nsq
        xsub = vquery((1:ds) + (i-1)*ds,q);
        distab(:,i)= dicts{i}'*xsub;
    end
    dis = sumidxtab3(idxencode,coefencode,distab);
    dis = 2*dis + bdot;
    [dis1, ids1] = yael_kmin (dis, k);
    
    dis_pqc(q, :) = dis1;
    ids_pqc(q, :) = ids1;
            
end
tpq = cputime - t0;

fprintf('====================\n');
fprintf ('%s\n',dataset);
fprintf ('SPQ ADC learn  = %.3f s\n', tpqlearn);
fprintf ('SPQ ADC encode = %.3f s\n', tpqencode);
fprintf ('SPQ ADC search = %.3f s  for %d query vectors in a database of %d vectors\n\n', tpq, nquery, nbase);

% compute search statistics 
pq_test_compute_stats
